import{_ as e,p as t,q as c}from"./framework-96b046e1.js";const n={};function _(r,o){return t(),c("div")}const a=e(n,[["render",_],["__file","index.html.vue"]]);export{a as default};
