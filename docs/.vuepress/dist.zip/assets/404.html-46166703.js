import{_ as e,p as t,q as _}from"./framework-96b046e1.js";const c={};function r(n,o){return t(),_("div")}const a=e(c,[["render",r],["__file","404.html.vue"]]);export{a as default};
